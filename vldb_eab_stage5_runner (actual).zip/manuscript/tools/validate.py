"""Structural validation of the LaTeX source, for use where no engine is available.

This does not replace a compile. It catches the failures behind most first compile
errors: a missing \\input target, an unbalanced environment, a \\ref with no matching
\\label, a \\cite with no bibliography entry, and a graphics path that does not resolve.
Run it before every commit; run a real engine before every submission.

    python tools/validate.py
"""
from __future__ import annotations

import os
import re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

INPUT = re.compile(r"\\input\{([^}]+)\}")
LABEL = re.compile(r"\\label\{([^}]+)\}")
REF = re.compile(r"\\(?:ref|autoref|eqref)\{([^}]+)\}")
CITE = re.compile(r"\\cite[tp]?\{([^}]+)\}")
GRAPHIC = re.compile(r"\\includegraphics(?:\[[^\]]*\])?\{([^}]+)\}")
BIBKEY = re.compile(r"@\w+\{([^,]+),")


def read(path):
    with open(path, encoding="utf-8") as fh:
        return fh.read()


def collect(entry="main.tex"):
    """Follow \\input from the entry point, returning ([(relpath, text)], problems)."""
    seen, order, stack, problems = set(), [], [entry], []
    while stack:
        rel = stack.pop(0)
        if rel in seen:
            continue
        seen.add(rel)
        path = os.path.join(ROOT, rel if rel.endswith(".tex") else rel + ".tex")
        if not os.path.exists(path):
            problems.append(f"missing \\input target: {rel}")
            continue
        text = read(path)
        order.append((rel, text))
        stack.extend(INPUT.findall(text))
    return order, problems


def main() -> int:
    files, problems = collect()
    labels, refs, cites, graphics = set(), [], [], []

    for rel, text in files:
        stack = []
        for m in re.finditer(r"\\(begin|end)\{([^}]+)\}", text):
            kind, name = m.group(1), m.group(2)
            line = text[: m.start()].count("\n") + 1
            if kind == "begin":
                stack.append((name, line))
            elif not stack:
                problems.append(f"{rel}:{line} \\end{{{name}}} with no matching \\begin")
            elif stack[-1][0] != name:
                problems.append(
                    f"{rel}:{line} \\end{{{name}}} closes \\begin{{{stack[-1][0]}}} from line {stack[-1][1]}")
                stack.pop()
            else:
                stack.pop()
        for name, line in stack:
            problems.append(f"{rel}:{line} \\begin{{{name}}} never closed")

        labels |= set(LABEL.findall(text))
        refs += [(rel, r) for r in REF.findall(text)]
        for group in CITE.findall(text):
            cites += [(rel, k.strip()) for k in group.split(",")]
        graphics += [(rel, g) for g in GRAPHIC.findall(text)]

    for rel, r in refs:
        if r not in labels:
            problems.append(f"{rel}: \\ref{{{r}}} has no \\label")

    bib = os.path.join(ROOT, "bib", "references.bib")
    if os.path.exists(bib):
        keys = {k.strip() for k in BIBKEY.findall(read(bib))}
        for rel, c in cites:
            if c not in keys:
                problems.append(f"{rel}: \\cite{{{c}}} not in references.bib")
    else:
        problems.append("references.bib not found")

    # Resolve against \graphicspath as well as the document root, the way the engine does.
    gpaths = [""]
    pre = os.path.join(ROOT, "preamble.tex")
    if os.path.exists(pre):
        for block in re.findall(r"\\graphicspath\{(.+?)\}\s*$", read(pre), re.M):
            gpaths += re.findall(r"\{([^}]*)\}", block)
    for rel, g in graphics:
        hit = any(os.path.exists(os.path.join(ROOT, gp, g + ext))
                  for gp in gpaths for ext in ("", ".pdf", ".png", ".jpg"))
        if not hit:
            problems.append(f"{rel}: \\includegraphics{{{g}}} does not resolve")

    todo = sum(text.count("% TODO") for _, text in files)
    print(f"files {len(files)} | labels {len(labels)} | refs {len(refs)} | cites {len(cites)} "
          f"| figures {len(graphics)} | sections still stubbed {todo}")
    if problems:
        print(f"\n{len(problems)} problem(s):")
        for p in problems:
            print("  " + p)
        return 1
    print("no structural problems found. This is not a compile; run tectonic or latexmk before submitting.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
