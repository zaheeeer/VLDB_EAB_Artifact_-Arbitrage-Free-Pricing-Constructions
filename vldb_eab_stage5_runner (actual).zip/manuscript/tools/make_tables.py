"""Generate every LaTeX table in the paper from the saved result files.

No number is typed into a section by hand. Each function reads a CSV under ../results/
and writes one float file under ../floats/tables/. Re-run after any experiment changes;
never edit the generated files.

    python tools/make_tables.py
"""
from __future__ import annotations

import os

import sys

import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(os.path.dirname(ROOT), "results")
OUT = os.path.join(ROOT, "floats", "tables")
sys.path.insert(0, os.path.dirname(ROOT))

PRETTY = {
    "uniform": "flat fee (= UBP)",
    "size_proportional": "size proportional",
    "compute_metered": "compute metered",
    "monopoly_per_asset": "per-asset monopoly",
    "monotone_constrained": "monotone fitted",
    "qirana_weighted_coverage": r"\qirana{} weighted coverage",
    "qirana_shannon": r"\qirana{} entropy",
    "querymarket_viewcover": r"\querymarket{} view cover",
    "chawla_ubp": "uniform bundle (UBP)",
    "chawla_uip": "uniform item (UIP)",
    "chawla_lpip": "LP item (LPIP)",
    "chawla_cip": "capacity item (CIP)",
    "chawla_layering": "layering",
    "chawla_xos": "XOS",
}
PORTED = {"qirana_weighted_coverage", "qirana_shannon",
          "querymarket_viewcover", "chawla_ubp", "chawla_uip", "chawla_lpip",
          "chawla_cip", "chawla_layering", "chawla_xos"}
SUBSTITUTED = {"querymarket_viewcover"}
ORDER = list(PRETTY)


def _wrap(body, caption, label, cols, star=False):
    env = "table*" if star else "table"
    return (f"\\begin{{{env}}}[t]\n  \\centering\n  \\caption{{{caption}}}\n"
            f"  \\label{{{label}}}\n  \\begin{{tabular}}{{{cols}}}\n    \\toprule\n"
            f"{body}\n    \\bottomrule\n  \\end{{tabular}}\n\\end{{{env}}}\n")


def _mark(name):
    s = PRETTY[name]
    if name in SUBSTITUTED:
        s += r"$^{\dagger}$"
    return s


def cross_workload():
    df = pd.read_csv(os.path.join(RES, "full_cross_workload.csv"), index_col=0)
    head = ("    mechanism & \\multicolumn{2}{c}{revenue} & \\multicolumn{2}{c}{welfare} "
            "& \\multicolumn{2}{c}{served} \\\\\n"
            "    \\cmidrule(lr){2-3}\\cmidrule(lr){4-5}\\cmidrule(lr){6-7}\n"
            "    & \\tpch{} & \\sqlshare{} & \\tpch{} & \\sqlshare{} & \\tpch{} & \\sqlshare{} \\\\\n"
            "    \\midrule")
    rows = [head]
    for m in ORDER:
        if m not in df.index:
            continue
        r = df.loc[m]
        rows.append("    {} & {:.3f} & {:.3f} & {:.3f} & {:.3f} & {:.2f} & {:.2f} \\\\".format(
            _mark(m), r.revenue_strategic_norm_tpch, r.revenue_strategic_norm_sqlshare,
            r.welfare_strategic_norm_tpch, r.welfare_strategic_norm_sqlshare,
            r.served_strategic_tpch, r.served_strategic_sqlshare))
    cap = ("Revenue, welfare and coverage against recomposing buyers, both workloads, "
           "normalized by the in-sample per-asset monopoly revenue. Mean over four "
           "valuation families and five seeds. Revenue and welfare order the mechanisms "
           "differently on both workloads. $\\dagger$: catalog substituted on "
           "\\sqlshare{} (Section~\\ref{sec:mechanisms}).")
    return _wrap("\n".join(rows), cap, "tab:cross", "lcccccc", star=True)


def audits():
    t = pd.read_csv(os.path.join(RES, "full_tpch_summary.csv"), index_col=0)
    s = pd.read_csv(os.path.join(RES, "full_sqlshare_summary.csv"), index_col=0)
    rows = ["    mechanism & \\multicolumn{2}{c}{information arb.} & "
            "\\multicolumn{2}{c}{combination arb.} & \\multicolumn{2}{c}{max gain} \\\\\n"
            "    \\cmidrule(lr){2-3}\\cmidrule(lr){4-5}\\cmidrule(lr){6-7}\n"
            "    & \\tpch{} & \\sqlshare{} & \\tpch{} & \\sqlshare{} & \\tpch{} & \\sqlshare{} \\\\\n"
            "    \\midrule"]
    for m in ORDER:
        if m not in t.index or m not in s.index:
            continue
        rows.append("    {} & {:.3f} & {:.3f} & {:.3f} & {:.3f} & {:.3f} & {:.3f} \\\\".format(
            _mark(m), t.loc[m, "mono_violation_rate"], s.loc[m, "mono_violation_rate"],
            t.loc[m, "comb_violation_rate"], s.loc[m, "comb_violation_rate"],
            t.loc[m, "comb_max_gain"], s.loc[m, "comb_max_gain"]))
    cap = ("Arbitrage audits. Information arbitrage is the fraction of verified "
           "derivability pairs whose prices invert; combination arbitrage is the "
           "fraction of assets a verified reconstruction plan buys more cheaply. Every "
           "reported violation is backed by a re-executed plan.")
    return _wrap("\n".join(rows), cap, "tab:audits", "lcccccc", star=True)


def generalization():
    t = pd.read_csv(os.path.join(RES, "full_tpch_summary.csv"), index_col=0)
    s = pd.read_csv(os.path.join(RES, "full_sqlshare_summary.csv"), index_col=0)
    rows = ["    mechanism & \\tpch{} & \\sqlshare{} \\\\\n    \\midrule"]
    for m in ORDER:
        if m not in t.index:
            continue
        rows.append("    {} & {:+.3f} & {:+.3f} \\\\".format(
            _mark(m), t.loc[m, "generalization_gap"], s.loc[m, "generalization_gap"]))
    cap = ("Generalization gap: fraction of training revenue lost on a held-out buyer "
           "sample. Positive is loss. The revenue-maximizing algorithms assume valuations "
           "are revealed to the seller, and that assumption is expensive on the generated "
           "workload and cheap on the real one.")
    return _wrap("\n".join(rows), cap, "tab:generalization", "lcc")


def sampling():
    df = pd.read_csv(os.path.join(RES, "support_sampling_comparison.csv"))
    rows = ["    support sampling & priceable assets & median $|C_S|$ & price levels & build (s) \\\\\n    \\midrule"]
    for r in df.itertuples():
        rows.append("    {} & {} / 222 & {} & {} & {} \\\\".format(
            r.sampling.replace("_", " "), r.assets_priceable, r.median_conflict_set,
            r.distinct_price_levels, r.build_seconds))
    cap = ("Support-set sampling on the largest \\sqlshare{} market, $|S| = 1000$. "
           "Sampling proportional to table size, which is what uniform sampling over the "
           "database amounts to, is nearly uncorrelated with which tables assets read "
           "($r = -0.088$).")
    return _wrap("\n".join(rows), cap, "tab:sampling", "lrrrr", star=True)


def fidelity():
    import ports as P
    import ports_chawla as C
    fid = {}
    fid.update(getattr(P, "FIDELITY", {}))
    fid.update(getattr(C, "FIDELITY", {}))
    rows = ["    mechanism & source & deviation \\\\\n    \\midrule"]
    for k in ORDER:
        if k not in fid:
            continue
        f = fid[k]
        dev = f.get("deviation", "none")
        rows.append("    {} & {} & {} \\\\".format(
            _mark(k), f.get("source", "")[:46], (dev if dev != "none" else "none")[:64]))
    cap = ("Port fidelity. No original author implementation was located for any of the "
           "three systems, so every mechanism is a reimplementation from the paper's "
           "defining rule.")
    return _wrap("\n".join(rows), cap, "tab:fidelity", "p{0.20\\textwidth}p{0.30\\textwidth}p{0.40\\textwidth}", star=True)


def markets():
    p = os.path.join(RES, "all_markets_runs.csv")
    if not os.path.exists(p):
        return None
    df = pd.read_csv(p)
    df = df[df.status == "ok"]
    if df.empty:
        return None
    g = df.groupby("mechanism")[["revenue_norm", "welfare_norm"]].agg(["mean", "std"])
    rows = ["    mechanism & revenue (mean $\\pm$ sd) & welfare (mean $\\pm$ sd) \\\\\n    \\midrule"]
    for m in ORDER:
        if m not in g.index:
            continue
        rows.append("    {} & {:.3f} $\\pm$ {:.3f} & {:.3f} $\\pm$ {:.3f} \\\\".format(
            _mark(m), g.loc[m, ("revenue_norm", "mean")], g.loc[m, ("revenue_norm", "std")],
            g.loc[m, ("welfare_norm", "mean")], g.loc[m, ("welfare_norm", "std")]))
    n = df.market.nunique()
    cap = (f"Spread across all {n} \\sqlshare{{}} markets with at least eight priced assets, "
           "reduced protocol (no cover planner). The welfare ordering is reported with its "
           "dispersion rather than from a single market.")
    return _wrap("\n".join(rows), cap, "tab:markets", "lcc", star=True)


def main():
    os.makedirs(OUT, exist_ok=True)
    built = []
    for name, fn in (("tab_cross", cross_workload), ("tab_audits", audits),
                     ("tab_generalization", generalization), ("tab_sampling", sampling),
                     ("tab_fidelity", fidelity), ("tab_markets", markets)):
        try:
            body = fn()
        except Exception as exc:
            print(f"SKIP {name}: {type(exc).__name__}: {exc}")
            continue
        if body is None:
            print(f"SKIP {name}: no input yet")
            continue
        with open(os.path.join(OUT, name + ".tex"), "w", encoding="utf-8") as fh:
            fh.write(body)
        built.append(name)
    with open(os.path.join(ROOT, "floats", "tables.tex"), "w", encoding="utf-8") as fh:
        for b in built:
            fh.write("\\input{floats/tables/%s}\n" % b)
    print("built:", ", ".join(built))


if __name__ == "__main__":
    raise SystemExit(main())
