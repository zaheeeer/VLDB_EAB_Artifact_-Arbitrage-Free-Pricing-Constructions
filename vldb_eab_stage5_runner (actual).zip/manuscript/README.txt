COMPILE ORDER
  1. python tools/make_tables.py     regenerates every table from ../results/
  2. tectonic main.tex               (or: latexmk -pdf main.tex)
  3. python tools/validate.py        structural check; not a substitute for a compile

VENUE TEMPLATE
  Drafted against IEEEtran (ICDE). IEEEtran.cls is not redistributed here. Place it
  beside main.tex and switch the \documentclass line; main.tex currently falls back to
  the article class so the source compiles without it. NO COMPILE TEST HAS BEEN RUN:
  no LaTeX engine was available in the authoring environment.

REFERENCE STYLE
  IEEE numeric. bib/references.bib is generated from Crossref publisher records and
  every entry carries a DOI. Do not hand-edit; regenerate.

RULE FOR NUMBERS
  No value is typed into a section by hand. Every table comes from tools/make_tables.py
  reading ../results/. If a number changes, re-run step 1; never edit prose.

CHANGES SINCE PREVIOUS VERSION
  - Third published system ported (revenue-maximization algorithms), 11 ported
    constructions in total.
  - Buyer surplus and welfare added to every run; welfare reverses the revenue ranking.
  - All 15 SQLShare markets priced, replacing the single-market result.
  - Support-set sampling comparison added.
  - Earlier claim that sampling breaks arbitrage-freeness RETRACTED; replaced by the
    falsification result, which is the correct reading of the same measurements.
  - Bibliography rebuilt from publisher records; all entries now carry DOIs.
