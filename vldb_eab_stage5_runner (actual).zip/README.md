# V8 recovery and validation checkpoint

Prepared September 21, 2026. This is a recovery checkpoint and revision plan, not a
revised submission or a reproduction of the paper's headline experiments.

Start with `Recovery_Findings.md`, then `V8_EAB_Revision_Plan.md`. The issue register
in `evidence/concern_register.csv` maps each concern to evidence, an action, and a
completion criterion.

## What is included

- `manuscript/`: unchanged files from the newly supplied V8 source archive.
- `legacy/`: unchanged top-level Python modules and CSVs from `artifacts.zip`.
- `evidence/original_file_manifest.json`: input hashes and provenance of copied files.
- `evidence/recovered_cells.json`: selected original notebook cells and saved output.
  Cell indices are zero-based. Saved notebook output is historical evidence, not a
  fresh measurement. These cells contain dependencies on earlier notebook state.
- `evidence/recovered_original_helpers.py`: five verbatim recovered helper definitions.
  The file is evidence, not a complete executable SQLShare driver. Callers still need
  globals such as query metadata, database handles, catalogs, and answer maps.
- `candidate/protocol.py`: newly written candidate corrections, clearly separate from
  historical code. These helpers have not been integrated into the full experiment.
- `scripts/` and `tests/`: repeatable historical arithmetic checks and small correctness
  fixtures. They do not silently update or replace paper results.
- `validation/`: recorded test, arithmetic, smoke-run, and manuscript-build outputs.

## Repeat the focused checks

Use Python 3.12 and an environment with the pinned validation dependencies. For example:

```bash
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements-validation.txt
.venv/bin/python -m pytest tests -q
.venv/bin/python scripts/recompute_audit.py
.venv/bin/python scripts/smoke_tpch.py
```

Run these commands from this directory. The TPC-H fixture uses DuckDB's `tpch`
extension; installation may require network access on first use. It generates a
tiny SF0.001 database in memory. No SQLShare download is needed for these checks.

The recorded checks used Python 3.12.14 in a separate virtual environment inheriting
installed scientific packages. A pristine operating-system/container rebuild has not
been demonstrated. The requirements file pins the direct validation dependencies,
not the entire historical environment. Exact observed versions appear in the smoke
result JSON.

## What passed

Eleven focused tests passed. The TPC-H smoke fixture generated 6,005 lineitem rows
and evaluated eight assets over two nonempty months. Four cheaper plans reconstructed
correctly; six single-source derivations matched. A deliberately corrupted plan was
rejected and an unchecked plan was excluded from the corrected effective-price helper.

The fixture still calls the legacy planner and answer matcher. It does not certify
solver timeout handling, empty/NULL aggregate semantics, arbitrary SQL bag semantics,
all fifteen mechanisms, or any published theorem. Those remain revision gates.

## Manuscript build status

A local compile was attempted and stopped because `acmart.cls` is absent from the
environment and archive. See `validation/main.log`. No new manuscript PDF was produced.
The appropriate public venue template and dependencies must be installed during the
manuscript build stage; this does not require another source file from the author.
Metadata, source comments, and the inherited README also need reconciliation with
the intended venue. Original manuscript bytes have been preserved.

## Boundaries

Do not use the generic replay script from the supplied bundle as a final reproduction
command. Its segments rely on earlier kernel state, contain historical failures, and
include unrelated live-service calls. Selected cells were inspected and recovered;
the notebooks were not blindly replayed.

Do not mix `historical_*` reporting outputs or the small smoke fixture with future
corrected campaign results. Preserve a separate configuration and result directory for
every scientific experiment. Full TPC-H and SQLShare reruns remain outstanding.
