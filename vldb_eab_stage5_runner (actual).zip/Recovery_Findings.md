# V8 recovery: findings and next actions

Prepared September 21, 2026, after examining `V8_vldb_eab_final_complete.zip`,
`bundle-278ea99c-full.zip`, and the earlier manuscript, code, and CSV uploads.

**Assessment:** the new archives recover the manuscript source and enough notebook
history to identify the main experimental pathways. They remove the immediate need
to ask the author for more source files. They also establish substantive correctness
and scope issues. The scientific conclusions still require corrected experiments.
No revised headline result is claimed here.

## What has now been recovered

The V8 archive contains 28 manuscript files, including LaTeX sections, bibliography,
tables, and figures. Its principal claims agree with the passages previously reviewed
in V8.pdf. A rendered equivalence check remains pending because the local compile
stopped at the missing `acmart.cls` dependency.

The bundle contains eight notebook segments with embedded execution history. Five previously missing definitions were recovered: `build_view2`, `fp_sql`,
`delete_one`, `qirana_from_edges`, and `sqlshare_plan_all`. Their exact definitions,
cell coordinates, and selected recorded outputs are preserved in `evidence/`.
`build_ledger` was not recovered as a named definition; the new audit script and
register are explicitly new work, not attributed to the original notebook.

The final TPC-H and SQLShare callbacks are now identifiable. The saved original
database files, answer maps, and several NumPy caches are still absent. Those are
rebuild tasks. The notebook segments do not constitute a clean standalone driver:
they reuse earlier globals and include failed historical attempts.

## Findings that change the plan

| Priority | Confirmed finding | Consequence and required action |
|---|---|---|
| P0 | The final TPC-H callback calls `plan_all(..., verify_limit=8)` and then uses every returned cheaper cost. | Successful verification must gate both strategic settlement and arbitrage metrics. Rerun affected TPC-H results with complete checks or cached verified witnesses. |
| P0 | The TPC-H CSV records 1,541 cheaper asset/run outcomes but only 387 successful plan checks. | At least 1,154 such outcomes lack a recorded successful check in that campaign. These are repeated asset/run instances, not necessarily unique plans. This does not prove that those plans were wrong; it disproves the claimed verification coverage. |
| P0 | SQLShare's recovered callback applies a discount only after `verify_row_cover` succeeds. It records 3,404 successes and six failures. | Failure gating was present for this workload. Across both final campaigns, 3,791 means successful checks; 3,797 means attempted checks, including failures. Neither count demonstrates that every TPC-H outcome was verified. |
| P0 | `run_full` calls the buyer sampler twice, and the sampler redraws the popularity ranking each time. | The reported generalization gap mixes new buyers with a new demand distribution. Establish separate stationary and shifted-demand conditions. |
| P0 | Score-based calibration stops at 60; flat pricing with buyer values of 100 therefore cannot reach its optimum. | Use training-value breakpoints or a validated adaptive search. This can alter relative rankings and requires a rerun. |
| P0 | The recovered entropy helper assigns each distinguished support point its own answer class. | Compute actual answer partitions on tractable cases. The candidate helper only computes entropy after valid class labels are supplied; generating those labels is still unfinished. |
| P0 | `delete_one` samples a row using unseeded SQL sampling and refuses a value pattern shared by duplicates. | The supplied NumPy seed does not control which row is deleted; duplicate-valued rows are excluded. Rebuild the sampler with durable row IDs, logged support draws, and explicit error counts. |
| P1 | The final TPC-H driver uses Q1/Q6-derived families, not seven query templates. | Correct the workload description immediately in the future revision. Add broader query families only where they address a specific generalization gap. |
| P1 | The final main SQLShare comparison has 222 assets and 2,017 cleaned audit pairs, after removing 30 of 2,047 original pairs. | Describe the main experiment as the largest market. Keep original-oracle, cleaned-audit, and all-market denominators separate. |
| P1 | The full experiments pass a vector of ones as answer-column counts. | `answer_cells` is actually answer-row count in these calls. Measure columns before rerunning, or accurately rename the valuation proxy. |
| P1 | The final SQLShare QueryMarket score uses the cheapest single catalog predecessor and a fallback price; the catalog has 105 assets. | Do not describe this score as an unrestricted multi-view cover optimizer. Validate a fuller port or label and justify this substitution. Unavailable targets need an explicit status. |
| P1 | The 15-market extension uses six mechanisms, three seeds, and two identical family labels; it has no strategic planner. | Treat it as a separate reduced experiment. Regenerate distinct families and scope strategic claims to experiments with actual recomposition. |
| P1 | The notebook prints a TPC-H false-edge count using `sum(1 for ... if False)`. | That particular printed zero is a constant, not an audit. Establish the claimed zero through an actual containment/reconstruction check; other earlier evidence must be evaluated separately. |

The other concerns in the revision plan remain: mechanism fidelity and newer relevant
baselines; buyer-accessible reconstruction programs; monotone relaxation mislabeled as
optimization; workload attrition; uncertainty and maxima; runtime and memory scaling;
failure cases; and manuscript presentation. A repaired sampler or smoke test does not
establish the assumptions needed for a published arbitrage-free guarantee.

## What has been completed in this checkpoint

1. Preserved original input identities and unchanged copies of 77 manuscript/code/CSV
   files; extracted 18 relevant notebook cells with their historical outputs.
2. Recomputed the full historical summaries and cross-workload table. The largest
   absolute numeric discrepancy from the saved means is approximately 2.22e-16.
   This establishes arithmetic consistency, not experimental validity.
3. Generated separate reporting tables that distinguish global maximum gain from
   mean per-run maximum, and summarize market means before computing across-market SD.
   For QIRANA welfare, that SD is 0.741772, versus the old pooled-row SD of 1.019995.
   For the SQLShare monotone heuristic, global maximum gain is 0.695708, versus a mean
   per-run maximum of 0.069272; two of 20 runs have positive combination violations.
4. Added candidate helpers for fixed/shifted demand, breakpoint calibration, entropy
   of supplied answer classes, verified-only effective prices, and seeded deletion
   on a fixed DuckDB base-table snapshot. Eleven focused tests passed.
5. Ran a genuine TPC-H SF0.001 fixture: 6,005 lineitem rows, eight assets, four verified
   cheaper plans, and six verified single-source derivations. A deliberately corrupted
   plan was rejected; an unchecked plan did not lower its target's corrected price.

The candidate helpers have **not** been integrated into a full corrected campaign.
The fixture still uses the legacy planner/matcher and deliberately uses nonempty
months. Solver status reporting, NULL/empty aggregates, general bag semantics,
full mechanisms, and the SQLShare pipeline remain open. No new comparative paper
tables or manuscript prose were substituted for the original results.

## Execution sequence from here

1. **Finish portable drivers and semantic checks.** Rebuild missing state from source;
   log dataset/query identities and every solver/verification outcome. Complete
   small reference cases for each retained mechanism before expensive comparisons.
2. **Integrate and freeze the protocol.** Use paired mechanisms, fixed demand for
   stationary experiments, independent random streams, genuine valuation measures,
   fair calibration, exact entropy where feasible, and explicit unavailable outcomes.
3. **Run a resource pilot, then the corrected campaign.** Start with the two original
   workloads and the largest SQLShare market. Add targeted generalization, sampling,
   fidelity, market-replication, and scaling experiments only after their inputs pass.
4. **Regenerate claims and revise V8.** Reconcile counts, regenerate statistics,
   distinguish observations from guarantees, report failures, and derive actionable
   lessons. Weaken or remove conclusions that do not survive the corrected protocol.
5. **Rebuild and package the submission.** Use the appropriate official template;
   repair references, tables, captions, and metadata; provide a portable artifact
   command and fresh-process reproduction record.

The accompanying plan supplies specific completion criteria for all seven stages.
Stages 2–3 are not closed by this checkpoint. Calendar estimates should follow the
resource pilot, rather than assuming the historical notebook timings will recur.

## Dependencies and author input

No additional archive is needed from the author now. The
[official SQLShare release page](https://uwescience.github.io/sqlshare/data_release.html)
identifies the public data source. Its archive endpoint responded successfully to a
header request during this inspection and reports 3,646,871,470 compressed bytes;
the historical notebook lists approximately 25.4 GB uncompressed. The complete data
has not been downloaded in this checkpoint. Selective extraction and a resource
pilot are appropriate before allocating the full campaign.

Later author input is needed only for information that cannot be reconstructed:
the intended submission deadline; available compute if local resources prove
insufficient; and truthful funding, ethics, conflicts, authorship, and artifact-release
statements. Original hardware metadata must remain unknown unless documented; the
new experiments will record their own environment. Publication or external sharing
is outside this checkpoint.
