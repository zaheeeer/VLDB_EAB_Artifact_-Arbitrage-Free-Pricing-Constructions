# V8 EAB revision and validation plan

Prepared for Zaheer Ahmad Gondal on September 21, 2026. Updated after inspecting the V8 source ZIP and notebook bundle.

**Target:** PVLDB, Experiment, Analysis & Benchmark (EA&B), Volume 20 / VLDB 2027. This is a revision plan, not a revised manuscript or a certification of reproducibility. Completion criteria below are intended to make the work auditable. They cannot guarantee acceptance.

## 1. Assessment after inspecting the supplied artifacts

The paper has a usable experimental foundation. The saved full-run CSVs reproduce the main summary and cross-workload tables to floating-point precision. The new V8 source and notebook bundle recover most previously missing helper definitions and identify the final experiment callbacks. However, the package mixes generations of results, still needs portable drivers and rebuilt state, and contains methodological problems that could change the conclusions. Correctness and provenance must come before additional scale or manuscript polishing.

I inspected V8, the CSVs, the earlier artifact archive, the exact-named V8 source archive, and the notebook bundle. I recomputed historical aggregates, recovered five helper definitions, ran eleven focused candidate-correction tests, and completed an eight-asset TPC-H SF0.001 smoke fixture. I did not rerun the full TPC-H or SQLShare campaigns, verify the public repository, or certify every port against its publication. A manuscript compile stopped at the missing acmart class; the supplied structural checker also found an unresolved sec:protocol reference. Original uploads remain unchanged. See the accompanying Recovery_Findings.md and evidence/concern_register.csv for exact notebook provenance and status.

### What is established from the files

| Evidence | Verified observation | Implication |
|---|---|---|
| Standalone CSVs versus archive copies | Both files are byte-for-byte identical. | There is no discrepancy between these upload copies. |
| `full_tpch_runs.csv`, `full_sqlshare_runs.csv` | Each has 300 rows: 15 mechanisms × four families × five seeds, without duplicate experiment keys. | The existing full-result summaries can be audited without immediately rerunning experiments. |
| `full_*_summary.csv`, `full_cross_workload.csv` | Their overlapping numeric columns reproduce from the full-run CSV means within floating-point precision. | This verifies aggregation, not the correctness of the experiments that generated the rows. |
| Mechanism inventory | Ten ports and five baselines are listed. | V8's eleven-ports/four-baselines and four-ports/two-systems descriptions must be reconciled. Equivalent mechanisms should also be disclosed. |
| Plan counters | Recovered final callbacks establish 3,791 successful checks and six failures: 3,797 attempted checks. TPC-H has 387 successes; SQLShare has 3,404 successes and six failures. | Older 4,651/zero counts belong to an earlier campaign. The final TPC-H callback capped verification at eight per run, so even the corrected attempted count does not cover every reported cheaper outcome. |
| `all_markets_runs.csv` | 546 rows: 540 successful result rows and six `too_small` status rows. Successful rows cover 15 markets, six mechanisms, two family labels, and three seeds. | This is a separate, reduced protocol, not 15 full repetitions of the main experiment. |
| All-market valuation families | The 270 `answer_cells` rows exactly duplicate the corresponding 270 `support_rows` rows after removing the family label. `market_run.py` supplies the same information vector to both. | These are not two independent valuation conditions. Do not use their duplication to support robustness or enlarge the effective sample size. |
| Workload structure | The all-market structure file totals 812 assets and 2,974 pairs. The older lattice file totals 806 materialized assets and 2,972 pairs. | Use versioned asset and market IDs to reconcile the populations. Do not choose a count because it matches existing prose. |
| Welfare ordering | Both information-proportional representatives exceed flat pricing and UBP in all 15 market means under the supplied reduced protocol. In the full SQLShare `support_rows` family, QIRANA weighted-coverage welfare is about 1.433, below UBP's 1.468. | The aggregate finding has support, but a claim that the reversal holds in every valuation family does not. |
| Zero prices | Four of the 15 reduced-protocol markets have all assets at zero conflict-set price. The median zero-price fraction is 37.5%. | Zero-price outcomes need explicit economic interpretation and cannot all be described as positive pricing coverage. |

### Additional problems that the plan must resolve

1. **Training and testing change demand as well as buyers.** `tpc_experiment.py::buyer_sample` draws a new popularity ranking on every call. The recovered full driver confirms that the reported gap combines sampling variation with a change in the underlying demand distribution. Candidate fixed/shifted-demand helpers now pass small tests, but must be integrated and rerun.
2. **Scale calibration has a restrictive ceiling.** `fit_scale` searches a fixed grid ending at 60 after score normalization. UBP searches observed buyer values. A simple diagnostic with values of 100 confirms that the grid cannot find the optimal flat price of 100. Quantify its effect on the paper's comparisons before calling the tuning treatment equal.
3. **Entropy remains an approximation.** `ports.py::qirana_scores` assigns each distinguished neighbor a separate answer class. Two row deletions can produce the same aggregate answer. A two-neighbor count example gives one bit under the code and zero for the actual answer partition. The recovered SQLShare helper makes the same singleton assumption. Establish actual answer partitions, including repeated aggregate outcomes, before retaining an entropy-based comparison.
4. **The monotone baseline is described differently from its implementation.** The supplied `enforce_monotone` raises predecessor prices by repeated relaxation. It is not the revenue-oriented coordinate-ascent optimizer described in V8.
5. **Answer matching is not automatically an executable buyer strategy.** `sqlshare_lattice.py::try_selection` constructs its filter from target-answer values. Audit which rewrite parameters a buyer can obtain from public query text, metadata, and purchased results. Separate an auditor with privileged access from an executable buyer.
6. **Verification must gate outcomes.** The final TPC-H callback uses every cheaper cost despite checking at most eight plans per run. Its CSV contains 1,541 positive asset/run cases and only 387 successful checks: at least 1,154 lack a recorded successful check in that campaign. The recovered SQLShare callback correctly excludes failures. The candidate gate rejects failed and unchecked plans in tests, but the full experiments still need integration and reruns.
7. **Statistics are mislabeled.** Table 6's standard deviations pool market/family/seed rows, rather than first calculating each market's mean. For QIRANA welfare, the pooled SD is about 1.020; the SD of the 15 market means is about 0.742. Table 4's reported maxima are means of per-run maxima. Rounding also hides positive violations: two SQLShare monotone-baseline runs have nonzero combination arbitrage.
8. **Recovery is substantial, but the portable driver is unfinished.** Definitions for `qirana_from_edges`, `fp_sql`, `delete_one`, and `build_view2`, plus the SQLShare final callback, have now been recovered. A named `build_ledger` definition remains absent; the checkpoint audit/register are new code. Database/answer state and several caches must be rebuilt. The V8 archive supplies acmart-based source, with stale ICDE comments and metadata. The earlier seven-mechanism README remains historical.
9. **The truncated fidelity table is caused by code.** `tools/make_tables.py::fidelity` deliberately slices source and deviation text to 46 and 64 characters. Its error handling can also skip failed table builds while allowing the script to finish. These behaviors must be corrected before regeneration.

10. **Workload descriptions overstate scope.** The final TPC-H driver uses Q1/Q6-derived families, not seven query templates. The main SQLShare comparison is one 222-asset market. Preserve a separate scope for the reduced 15-market extension.
11. **Some measured quantities are proxies.** Both full drivers pass column-count vectors of ones, so `answer_cells` actually uses answer-row count. The final SQLShare QueryMarket score uses a cheapest single catalog predecessor, not general multi-view cover, with an arbitrary fallback for unavailable targets.
12. **Sampling is not fully seeded and excludes duplicates.** Recovered `delete_one` does not use its NumPy generator for row selection and skips duplicate-valued rows. The TPC-H zero-falsification print in one notebook cell is a constant expression, not an executed check. Both claims need actual logged sampling/semantic tests.

### Checkpoint status after the new archives

| Stage | Status | Remaining gate |
|---|---|---|
| 1. Recovery and provenance | Core source/helpers recovered; historical inventory and runnable fixture prepared. | Rebuild full SQLShare state and portable drivers; complete claim-level provenance. |
| 2. Mechanisms and semantics | Candidate verification gate and narrow reconstruction fixtures pass. | All retained ports, actual entropy partitions, buyer capability, NULL/bag semantics, and solver outcomes. |
| 3. Buyer and calibration protocol | Candidate fixed-demand, breakpoint, and seeded-deletion tests pass. | Integrate into drivers, measure actual valuation quantities, and freeze the run configuration. |
| 4. Historical reporting | Summary arithmetic reproduced; corrected SD/max reporting generated separately. | Reconcile asset IDs/populations and regenerate results after protocol changes. |
| 5. Targeted experiments | Small SF0.001 TPC-H fixture completed. | Resource pilot and corrected full comparison/controls/scaling. |
| 6–7. Manuscript and artifact | V8 source recovered; structural/build issues recorded. | Evidence-based revision, final compile/render, and fresh-environment reproduction. |

These are progress states, not a claim that Stages 1–3 have passed in full. The eleven tests and smoke fixture validate narrow corrections only.

## 2. Execution order and completion criteria

Proceed in this order. Do not launch the expensive comparison campaign until Stages 1–3 pass. Findings that fail a check must be corrected, narrowed, or removed, even when that weakens the original narrative.

### Stage 1 — Establish one complete, reproducible starting point

**Addresses:** conflicting records, missing artifact components, uncertain manuscript version.

**Actions**

- **Completed:** preserve original upload hashes; locate the V8 source and notebook history; identify final `full_*` and reduced `all_markets_*` pathways; recover five missing helper definitions. Keep byte-identical historical copies separate from candidate corrections.
- Separate the synthetic pilot, earlier port experiments, full comparison, and reduced all-market campaign. The included ICDE plans and unrelated review memo are historical context, not instructions for the PVLDB revision.
- **Partly completed:** helper functions and final callbacks are recovered. Rebuild initialization, database preparation, missing caches and asset IDs; turn the notebook pathways into standalone drivers and recover plot/table commands. Label reconstructed code as new work and rerun affected claims rather than attributing old results to it.
- Create a claim-to-result register: manuscript location, claim, experiment version, file, row filter, formula, denominator, rounding, and status.
- Record exact software versions, machine details, dataset release/checksums, query IDs, row limits, seeds, solver settings, source commit, and output hashes.
- Provide a minimal command that builds a tiny fixture and completes one run from a fresh process, without notebook globals. Archive old results rather than overwriting them.

**Completion criterion:** A new process can load the dependencies, build the fixture, run one case, and regenerate one result table. Every retained V8 claim has either an identified source or an explicit unresolved status. Recover and document the SQLShare download source and preparation path.

**Owner/status:** I have built the recovery inventory, concern register, arithmetic audit, and small runnable fixture. No additional author archive is needed now. Full SQLShare preparation and complete claim-level provenance remain open.

### Stage 2 — Validate mechanisms, semantics, and the reconstruction auditor

**Addresses:** implementation fidelity, invalid causal attribution, verification failures.

**Actions**

- For each of the ten ports, map the original published definition and assumptions to the implementation. Record faithful portions, deliberate approximations, budgets, and unsupported cases in a complete fidelity table. Verify exclusions, including newer query-pricing work, against current primary sources.
- Compute entropy from actual answer-equivalence classes on tractable cases. Compare the singleton approximation against that calculation. Include repeated aggregate outcomes, duplicate rows, and unchanged answers.
- Compare QueryMarket prices against exhaustively enumerated valid view subsets on small fixtures. Test unavailable targets, catalog substitutions, and cheaper derivations of explicitly priced views.
- Check LPIP threshold sampling, CIP capacity search, layering's minimal-cover property, XOS combination, and uniform bundle/item pricing against their published definitions. Compare budgeted and exhaustive variants on small instances.
- Treat the monotone relaxation as a labeled heuristic unless a different optimizer is recovered. Do not imply optimality.
- Separate schema-level determinacy, verified instance-level reconstruction, and answer-containment diagnostics. Record the admissible database constraints and buyer information available in each setting.
- Freeze each reconstruction program before verifying it. Its executable inputs must be restricted to the stated buyer capabilities. Target answers can verify a candidate but must not silently supply hidden predicates or missing output data.
- Require `attempted`, `verified`, `failed`, `infeasible`, `timeout`, and `not_audited` outcomes. Only verified feasible purchases enter arbitrage and strategic settlement. A failed or timed-out search is not a proof of zero arbitrage.
- Save plan witnesses with target/source IDs, costs, reconstruction operation, answer hashes, and failure reasons. Preserve bag/set semantics, duplicates, nulls, types, and numerical tolerances.
- Use explicit counterexample databases to distinguish false oracle edges from mechanism defects. Check set containment directly; a larger target conflict-set size is sufficient to expose some failures but misses non-containment at equal or smaller size.

**Completion criterion:** Small independently checkable fixtures agree with reference calculations. Every reported exploit has an executable, verified witness under the stated information model. No claim that sampling invalidates a published guarantee remains without compatible assumptions and direct evidence.

### Stage 3 — Freeze a fair buyer and calibration protocol

**Addresses:** demand-shift confounding, identical valuation families, unequal tuning ranges.

**Actions**

- Define a same-distribution experiment: draw one asset-popularity vector, then independently sample training and test buyers from that vector.
- Keep redrawn or perturbed popularity as a separate, explicitly named demand-shift experiment. Use separate random streams for popularity, buyer values, support sampling, and data generation.
- Make valuation families use their stated quantities. Answer cells require row count × column count; support rows require actual documented provenance. If exact support is unavailable, label the proxy and do not advertise a distinct family when the resulting vectors coincide.
- Pair mechanisms on identical workload, support sample where applicable, training buyers, and test buyers. Keep test values out of calibration.
- Replace the arbitrary multiplier ceiling with an exact breakpoint search for nonnegative scaled scores, or demonstrate that a specified approximation reaches the relevant optimum. Handle zero scores explicitly. With constant scores and matched tie handling, the fitted flat baseline should agree with UBP.
- Define the normalization population and sample-size adjustment. Save raw revenue, surplus, total served value, counts, and denominators in addition to normalized metrics.
- Explain that welfare in this model is served buyer value. Include the free-access welfare ceiling as context, so giving information away is not mistaken for an unconditional commercial improvement.

**Completion criterion:** The stationary experiment uses one demand distribution; the shift experiment is separate; claimed distinct families are numerically distinct or explicitly collapsed; calibration is validated on small exact examples; the run configuration is fixed before the main campaign.

### Stage 4 — Regenerate existing results and correct their statistics

**Addresses:** inconsistent counts, aggregation errors, unsupported universal statements.

**Actions**

- Reconcile the 806/2,972 and 812/2,974 workload populations using asset and market identifiers. Explain the complete attrition path from 11,121 source queries through 975 nonempty answers to each evaluated subset.
- **Scope recovered:** the final main SQLShare experiment uses the largest 222-asset market and 2,017 cleaned audit pairs, after removal of 30 of 2,047 original edges. Preserve these distinct denominators in the new manifest. The separate 15-market extension has six mechanisms, three seeds, duplicate family labels, and no strategic planner.
- Report attempted, successful, and failed plan counts with one definition throughout the abstract, introduction, methods, and artifact.
- Show per-family and per-seed results. For comparisons, use paired differences on the same experiment conditions, with declared uncertainty estimates. Distinguish variability across buyer seeds, support samples, and markets.
- For across-market claims, average within each market first, then summarize the 15 market means. Do not treat the duplicated family rows or individual assets as independent replications.
- Report a global maximum as a maximum. If the intended metric is the mean of per-run maxima, label it accordingly. Pair violation rates with integer counts and sufficient precision to distinguish zero from a small positive value.
- Rebuild all prose numbers through generated macros or an equivalent auditable source. Make table generation fail when a required input is missing; retain full fidelity text.

**Completion criterion:** Every headline number has one reproducible calculation. All populations and uncertainty units are explicit. No visible zero masks an observed violation, and every statement about all families or all markets is checked against the corresponding disaggregated data.

### Stage 5 — Run only the experiments needed to support the revised claims

**Addresses:** analytical depth, missing controls, scalability, robustness.

The following is a proposed minimum campaign. Freeze the final grid after a small runtime/resource pilot and before examining the new comparative results. A workable starting design is ten buyer-split seeds for primary comparisons and five independent support draws for the targeted sampler study, without blindly taking the Cartesian product of every axis. These counts are planning choices, not guarantees of statistical power.

| Experiment | Proposed design | Decision it supports |
|---|---|---|
| Corrected main comparison | Validated mechanisms; TPC-H and the identified SQLShare full workload; genuinely distinct valuation families; matched stationary buyers. | Which revenue, welfare, and coverage rankings survive protocol repairs? |
| Generalization versus demand shift | Same workload and mechanisms; fixed popularity versus an explicitly controlled popularity change; training sizes such as 200, 800, and 3,200. | Is the observed loss caused by estimation, distribution change, or both? |
| Sampling sensitivity | Table-size versus readership sampling; support sizes such as 100, 300, 1,000, and 3,000; independent sampler seeds. Record zero prices, resolution, failures, build time, and peak memory. | What does the sampler change, and at what cost? |
| Semantic control | Supported rewrites with known assumptions versus instance-only edges; saved counterexample databases and executable purchase plans. | Are apparent violations properties of the mechanism, the port, or the oracle? |
| Implementation ablations | Exact versus budgeted LPIP; true versus approximate entropy partitions; catalog choices; uniform versus nonuniform support weights. | Which conclusions depend on implementation choices? |
| Across-market replication | Rerun the reduced protocol with genuine valuation distinctions. Prefer full recomposition on all 15 eligible markets. If infeasible, select a documented subset before outcomes and scope strategic claims to it. | Do conclusions extend beyond the largest market? |
| Scalability | Separate data scale, asset count, support size, and buyer count. Start with TPC-H SF 0.1/1/10 and 100/200/400/800 assets where valid and feasible. Record generation, query evaluation, pricing fit, audit, verification, and memory separately. | Where does each method become expensive or fail? |

Timing runs need a documented host, fixed threading, repeated measurements, and a stated cache/warm-up policy. Preserve timeouts and memory failures in the results. Expand beyond this grid only to resolve a specific remaining scientific uncertainty. A third dataset is useful only if it tests an uncovered workload property; dataset count alone is not the goal.

**Completion criterion:** Each retained contribution is supported by a direct comparison, diagnostic control, or scoped workload result. Uncertain rankings and negative outcomes remain visible. Runtime estimates for larger jobs come from the pilot, not unsupported calendar promises.

### Stage 6 — Revise the manuscript around the verified findings

**Addresses:** novelty, actionable lessons, misleading scope, manuscript consistency.

- Keep EAB as the paper type. Frame a small set of evaluation questions around revenue/welfare trade-offs, generalization, semantic validity, and operational cost. Map each contribution to its results and limitations.
- Distinguish replications of Chawla et al. from new cross-framework or workload findings. Replace sweeping claims such as no prior comparison with a precise, verified scope.
- Use one mechanism inventory and one workload/protocol table. Label equivalent constructions, proxies, and substituted catalogs.
- Align the abstract with the corrected experiment version. Retain only supported quantitative findings. Do not preserve a desired conclusion when a corrected experiment contradicts it.
- Repair Table 1, Figure 2's panel caption, the unresolved reference, and the inaccurate maximum/zero descriptions. Add only the plots needed for uncertainty, controls, and scaling.
- Turn Section 9's lessons into conditional guidance: which objective, workload, assumptions, and operating budget make each conclusion applicable.
- Confirm authorship, affiliations, CRediT roles, funding, conflicts, ethics/data permissions, and the AI-assistance disclosure with the author. Match the final title, abstract, and author information to CMT.

**Completion criterion:** Each contribution has evidence and an explicit scope. No stale experimental number, broken reference, or unsupported universal claim remains. The author reviews substantive changes and confirms personal declarations.

### Stage 7 — Complete the artifact and PVLDB submission checks

**Addresses:** reproducibility, current venue compliance, final presentation.

- Package the corrected code, pinned environment, configuration files, permitted data or a verified acquisition/preparation path, raw run logs, witnesses, result builders, figure builders, and complete instructions.
- Provide separate quick-start and full-reproduction commands, with expected outputs, resource requirements, and measured approximate runtimes.
- Reproduce the critical tables and figures in a clean environment. Audit a manageable witness sample independently in addition to checking the generator's own counters.
- Verify the supplied template against the current official PVLDB template. Preserve required typography, margins, captions, licensing, reference, and artifact blocks. Follow the project's no-running-header/footer/page-number requirement and balance the final columns.
- Check the EAB title suffix and CMT match, the applicable page limit, unresolved citations/references, overflow, float readability, effective raster resolution, and font embedding. Validate the requested PDF/A conformance after final compilation/conversion and visually inspect that final file. Record any unavailable validation.
- Deliver the manuscript source ZIP, final PDF, reproducibility package, revision log, and README with exact build and validation results. Publishing a new repository release or making a submission remains a separate author action.

PVLDB Volume 20 requires the full EAB reproducibility package with meaningful instructions at initial submission and requires EAB participation in reproducibility evaluation. The current limit is 12 pages excluding references; the category suffix is required in both the submitted manuscript title and CMT. See the [official submission guidelines](https://www.vldb.org/2027/submission-guidelines.html). Use the [official formatting guidance](https://www.vldb.org/2027/formatting-guidelines.html) when preparing the final build.

**Completion criterion:** The documented clean-environment workflow succeeds, the corrected results support the final claims, and the manuscript passes the recorded content and formatting checks.

## 3. What can proceed now and what I need from you

**No additional archive is needed from you now.** The V8 source and notebook bundle resolve the immediate source requests. Missing intermediate state will be rebuilt and labeled as such.

| Dependency | Current status and next action | Author help |
|---|---|---|
| V8 source | Recovered, with source/build issues recorded. Use the official venue template at final build. | None now. |
| Original experiment history | Final callbacks and five helpers recovered; standalone full drivers still need reconstruction. | None now; do not search for another archive you do not have. |
| SQLShare source data | Official public release located; archive header request succeeded. Approximately 3.65 GB compressed; historical listing about 25.4 GB uncompressed. Selective extraction and a resource pilot remain. | Only if access or local compute later proves insufficient. |
| Historic environment | Not fully recoverable from the supplied files. Record the new runtime accurately; never invent missing old hardware/version metadata. | Optional old logs if they happen to become available. |
| Full-campaign resources and deadline | Estimate resource needs from a small integrated pilot. | Deadline and available CPU/RAM/runtime will help schedule larger jobs when needed. |
| Author declarations and release | Draft and review funding, ethics, conflicts, authorship, data/code licensing, and artifact availability at the final stage. | Confirm personal/institutional facts and make the eventual submission/release decision. |

I can continue with portable drivers, semantic fixtures, mechanism review, and the corrected reporting workflow. If a large run cannot execute here, the handoff will contain exact commands, configuration, and expected output files. No large rerun is requested from you before the correctness and protocol gates pass.

## 4. Priority and stopping rules

1. **First:** recover the complete source and fix semantic/implementation/protocol issues.
2. **Second:** regenerate results, quantify uncertainty, and run the targeted controls and scaling measurements.
3. **Third:** revise claims, finish presentation, and validate the deliverables.

Do not submit while a headline result cannot be reproduced from an identified code/data version, an exploit lacks a valid witness, or a comparison depends on incompatible definitions. If a port cannot be validated, label it as an approximation and narrow the conclusion, or exclude it with a documented reason. If the corrected data overturn a finding, report the negative result. A reliable EAB contribution can survive a changed ranking; it cannot rely on unresolved attribution.

## 5. Evidence references and input identity

Local evidence is identified above by the original file names and function names. Tables refer to V8.pdf. The audit distinguished recomputation from saved CSVs, executable diagnostic examples, static source inspection, and experiments that still require reproduction.

- Chawla et al., *Revenue Maximization for Query Pricing*, PVLDB 13(1), 2019: [published paper](https://www.vldb.org/pvldb/vol13/p1-chawla.pdf). Its algorithm definitions provide the reference for the planned port checks; full implementation equivalence remains to be established.
- [PVLDB Volume 20 submission guidelines](https://www.vldb.org/2027/submission-guidelines.html), checked September 21, 2026.
- [VLDB 2027 formatting guidelines](https://www.vldb.org/2027/formatting-guidelines.html). Exact template verification belongs to the final build stage.
- [Official SQLShare public data release](https://uwescience.github.io/sqlshare/data_release.html). The public archive location is identified; full acquisition/preparation has not been completed in this checkpoint.

SHA-256 identities of the inspected inputs:

```text
V8.pdf
a726f94c73fe39d23840e1173a8103e0decad45c60c2adb205a963227beb24d3

artifacts.zip
9c87492997e658d792aa78e2011d8d4910df72dd4e0cd18770c49868c8aa9b5a

all_markets_runs.csv
365a522c932f2a217210b28c32db20e4ba458b911d5563837ae44da449460c79

all_markets_structure.csv
19e7ebaf2784bd3da4099aaac3d596d389823a0b5f9dad777b1736e4a561bf68
```

New archive identities (SHA-256):

```text
V8_vldb_eab_final_complete.zip
9fceec8bccf9746ec7ff748dda1e3838e774319a557f0f514facab53840a807b

bundle-278ea99c-full.zip
28e5f8ee8175757c1af25fb2bb5e62fdd0ae166647d49e1adc82467f933e73e6

```
